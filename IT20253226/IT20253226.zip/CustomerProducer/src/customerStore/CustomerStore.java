package customerStore;

import java.util.ArrayList;
import java.util.List;

import customerModel.Customer;

public class CustomerStore {
	public static List<Customer> customerList = new ArrayList<Customer>();

}
